# StudySphere

A biology study app with quizzes, flashcards, mastery tracking, a study assistant,
and a webcam-based "Phone Watch" focus monitor (uses TensorFlow.js + COCO-SSD to
detect a phone in frame and reset your score after 3 warnings).

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL it prints (usually http://localhost:5173).
Your browser will ask for camera permission the first time you enable
"Phone Watch" — allow it.

## Deploy to Vercel

### Option A — via GitHub (recommended)

1. Create a new GitHub repository and push this folder to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. Go to https://vercel.com and sign in (you can use your GitHub account).
3. Click "Add New… → Project".
4. Select the GitHub repo you just pushed.
5. Vercel auto-detects Vite. Leave the defaults:
   - Build Command: `npm run build` (or `vite build`)
   - Output Directory: `dist`
6. Click "Deploy". Wait ~1 minute.
7. Open the live URL Vercel gives you (something like `your-repo.vercel.app`).

### Option B — via Vercel CLI (no GitHub needed)

```bash
npm install -g vercel
cd studysphere-app
vercel
```

Follow the prompts (link to your Vercel account, accept defaults). It will
build and deploy, then give you a live URL.

## Notes on camera access

- The site must be served over **HTTPS** for `getUserMedia` to work — Vercel
  gives you HTTPS automatically, so this is handled for you.
- The first time you toggle "Phone Watch" on, the browser will prompt for
  camera permission. You must accept it for the feature to work.
- The phone-detection model (TensorFlow.js + COCO-SSD, ~6MB) loads from a CDN
  on first use, so it needs an internet connection.
