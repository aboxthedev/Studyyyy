import React from "react";
import ReactDOM from "react-dom/client";
import StudySphere from "./StudySphere";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <StudySphere />
  </React.StrictMode>
);
