import { useState, useEffect, useRef } from "react";

// ── DATA ──────────────────────────────────────────────────────────────────────

const SUBJECTS = {
  biology: {
    id: "biology",
    name: "Biology",
    icon: "🧬",
    color: "#10b981",
    units: {
      genetics: {
        id: "genetics",
        name: "Unit 1: The Code of Life",
        lessons: {
          dna_basics: {
            id: "dna_basics",
            name: "What is DNA?",
            overview: "DNA is the fundamental molecule of heredity, found in the nucleus of every cell. It stores all the genetic information needed for an organism to grow, function, and reproduce.",
            objectives: [
              "Define DNA and explain what the abbreviation stands for",
              "Identify where DNA is located in the cell",
              "Describe the double helix structure of DNA",
              "Explain the function of DNA in living organisms",
              "Understand the nucleotide as the monomer of DNA"
            ],
            keyConcepts: [
              { title: "DNA Structure", content: "DNA (Deoxyribonucleic Acid) is a polymer — a large molecule made of smaller repeating units called nucleotides. It forms a double helix: two strands twisted around each other, like a twisted ladder." },
              { title: "Location in the Cell", content: "DNA is found in the nucleus of the cell, organized into structures called chromosomes. Almost every cell has DNA, except a few like red blood cells." },
              { title: "Function of DNA", content: "DNA stores and codes the genetic information of organisms. It acts as the instruction manual of the body — telling cells how to grow, look, and function." },
              { title: "Nucleotide Structure", content: "A nucleotide has three parts: a deoxyribose sugar, a phosphate group, and a nitrogenous base. The four bases are Adenine (A), Thymine (T), Cytosine (C), and Guanine (G). Memory trick: 'Apple on the Tree; Car in the Garage' (A-T, C-G)." },
              { title: "Base Pairing Rules", content: "Bases on opposite strands pair specifically: Adenine pairs with Thymine (2 hydrogen bonds), and Cytosine pairs with Guanine (3 hydrogen bonds). These are called complementary base pairs." },
              { title: "Ring Structure", content: "Adenine and Guanine are double-ringed (purines), while Thymine, Cytosine, and Uracil are single-ringed (pyrimidines)." }
            ],
            vocabulary: [
              { term: "DNA", definition: "Deoxyribonucleic Acid — the molecule that carries genetic information in all living organisms", difficulty: "easy" },
              { term: "Nucleotide", definition: "The monomer (building block) of DNA, composed of a sugar, phosphate group, and nitrogenous base", difficulty: "medium" },
              { term: "Double Helix", definition: "The spiral staircase-like structure of DNA, consisting of two strands wound around each other", difficulty: "easy" },
              { term: "Complementary Base Pairs", definition: "The specific pairing of nitrogenous bases: A-T and C-G", difficulty: "medium" },
              { term: "Polymer", definition: "A large molecule made of many smaller repeating units (monomers)", difficulty: "medium" },
              { term: "Hydrogen Bond", definition: "A weak chemical bond connecting complementary base pairs in DNA", difficulty: "hard" },
              { term: "Nitrogenous Base", definition: "The part of a nucleotide that carries genetic information; either Adenine, Thymine, Cytosine, or Guanine", difficulty: "hard" },
              { term: "Chromosome", definition: "A structure in the nucleus made of DNA and protein; humans have 46 chromosomes", difficulty: "medium" }
            ],
            commonMistakes: [
              { error: "Confusing DNA and RNA bases", reason: "Students often forget that RNA uses Uracil instead of Thymine", fix: "Remember: RNA replaces T with U (Uracil Under the tree)" },
              { error: "Mixing up hydrogen bond counts", reason: "A-T and C-G bond counts are often swapped", fix: "C-G has 3 bonds (C comes before G, 3 > 2). A-T has 2 bonds." },
              { error: "Saying DNA is single-stranded", reason: "RNA is single-stranded, DNA is double-stranded", fix: "DNA = Double helix = 2 strands. RNA = 1 strand." }
            ],
            summary: "DNA is a double-helix polymer made of nucleotides (sugar + phosphate + base). Found in the cell nucleus, it stores genetic information. The four bases pair specifically: A with T (2 H-bonds) and C with G (3 H-bonds). RNA is similar but single-stranded and uses Uracil instead of Thymine.",
          },
          dna_rna: {
            id: "dna_rna",
            name: "DNA vs RNA",
            overview: "While DNA holds the master blueprint, RNA serves as the working copy that carries instructions out of the nucleus to make proteins — the building blocks of the body.",
            objectives: [
              "Distinguish between DNA and RNA",
              "Explain why RNA is necessary for protein synthesis",
              "List the bases present in RNA",
              "Understand the role of RNA as a messenger"
            ],
            keyConcepts: [
              { title: "What is RNA?", content: "RNA (Ribonucleic Acid) is also a nucleic acid polymer. It is single-stranded, unlike DNA's double helix." },
              { title: "RNA Bases", content: "RNA uses Adenine, Guanine, Cytosine, and Uracil — NOT Thymine. Memory trick: 'Apple Under the tree; Car in the Garage' (A-U, C-G)" },
              { title: "Why We Need RNA", content: "DNA cannot leave the nucleus. RNA can leave. DNA codes for protein production; RNA carries that code to the ribosome where proteins are assembled from amino acids." },
              { title: "Biomolecules", content: "DNA and RNA are nucleic acids — one of four families of biomolecules (large molecules produced by living organisms). The others are carbohydrates, proteins, and fats." }
            ],
            vocabulary: [
              { term: "RNA", definition: "Ribonucleic Acid — a single-stranded nucleic acid that carries genetic instructions from DNA", difficulty: "easy" },
              { term: "Uracil", definition: "The nitrogenous base in RNA that replaces Thymine found in DNA", difficulty: "medium" },
              { term: "Protein Synthesis", definition: "The process of building proteins using the instructions coded in DNA/RNA", difficulty: "hard" },
              { term: "Biomolecules", definition: "Large molecules produced by living organisms: carbohydrates, proteins, fats, and nucleic acids", difficulty: "medium" },
              { term: "Amino Acids", definition: "The building blocks of proteins, assembled according to RNA instructions", difficulty: "medium" }
            ],
            commonMistakes: [
              { error: "Thinking RNA has Thymine", reason: "Students copy the DNA base list without remembering the switch", fix: "RNA swaps T for U. Uracil is unique to RNA." },
              { error: "Thinking DNA makes proteins directly", reason: "The nucleus is often assumed to be the site of protein production", fix: "DNA → RNA → Protein. DNA stays in the nucleus; RNA exits to build proteins." }
            ],
            summary: "RNA is a single-stranded nucleic acid using bases A, U, C, G. Because DNA cannot leave the nucleus, RNA acts as a messenger — carrying the DNA code to build proteins. Both DNA and RNA are nucleic acids, part of the four biomolecule families."
          },
          dna_replication: {
            id: "dna_replication",
            name: "DNA Replication",
            overview: "Before a cell divides, it must duplicate its entire DNA so each daughter cell gets a complete set of genetic instructions. This precise copying process uses four specialized enzymes.",
            objectives: [
              "Define DNA replication and explain when it occurs",
              "Name and describe the role of all four replication enzymes",
              "Explain what Okazaki fragments are and why they form",
              "Understand the meaning of semi-conservative replication",
              "Distinguish between the leading and lagging strands"
            ],
            keyConcepts: [
              { title: "What is DNA Replication?", content: "DNA replication is the process of copying the entire DNA molecule before cell division. Each new cell needs a full copy of the genetic instructions." },
              { title: "When and Where?", content: "Replication happens in Interphase (the preparation phase before cell division), specifically during the S (Synthesis) phase. It takes place in the nucleus of the cell." },
              { title: "Helicase", content: "Helicase is the 'unzipper'. It breaks the hydrogen bonds connecting the base pairs (A-T, C-G), separating the two strands and creating a replication fork." },
              { title: "Primase", content: "Primase is the 'leader'. It lays down a short RNA primer that marks where DNA polymerase should begin building the new strand." },
              { title: "DNA Polymerase", content: "DNA Polymerase is the 'builder'. It reads the template strand and assembles free nucleotides from the nucleoplasm to build a new complementary strand." },
              { title: "Leading vs Lagging Strand", content: "DNA strands run antiparallel (one 5'→3', the other 3'→5'). DNA polymerase only builds 5'→3'. The leading strand is built smoothly. The lagging strand is built in fragments (Okazaki fragments) because polymerase must repeatedly restart. Analogy: copying notes facing the board (easy) vs. copying with your back to the board (fragments)." },
              { title: "Ligase", content: "Ligase is the 'gluer'. It joins the Okazaki fragments on the lagging strand into one continuous strand." },
              { title: "Semi-Conservative Replication", content: "Each new DNA molecule consists of one old (original) strand and one newly synthesized strand. This is called semi-conservative because half of the original DNA is conserved in each copy." },
              { title: "Nucleoplasm", content: "The nucleoplasm is the jelly-like fluid filling the nucleus. It contains the replication enzymes and free-floating nucleotides used to build new DNA strands." }
            ],
            vocabulary: [
              { term: "DNA Replication", definition: "The process of duplicating the DNA molecule before cell division", difficulty: "easy" },
              { term: "Interphase", definition: "The preparation phase before cell division, when DNA replication occurs", difficulty: "medium" },
              { term: "Helicase", definition: "Enzyme that unzips DNA by breaking hydrogen bonds between base pairs", difficulty: "medium" },
              { term: "Primase", definition: "Enzyme that lays an RNA primer to mark the starting point for DNA polymerase", difficulty: "hard" },
              { term: "DNA Polymerase", definition: "Enzyme that builds new DNA strands by adding complementary nucleotides", difficulty: "medium" },
              { term: "Ligase", definition: "Enzyme that seals (glues) Okazaki fragments into a continuous strand", difficulty: "medium" },
              { term: "Okazaki Fragments", definition: "Short DNA fragments produced on the lagging strand because DNA polymerase can only build in one direction", difficulty: "hard" },
              { term: "Leading Strand", definition: "The strand built continuously and smoothly in the 5' to 3' direction", difficulty: "hard" },
              { term: "Lagging Strand", definition: "The strand built in fragments because it runs antiparallel to the leading strand", difficulty: "hard" },
              { term: "Semi-Conservative Replication", definition: "Each new DNA molecule contains one original strand and one new strand", difficulty: "hard" },
              { term: "Nucleoplasm", definition: "The fluid inside the nucleus containing enzymes and free nucleotides", difficulty: "medium" }
            ],
            commonMistakes: [
              { error: "Thinking replication makes completely new DNA", reason: "Students assume both strands are new after replication", fix: "Each resulting DNA molecule has ONE old strand + ONE new strand (semi-conservative)." },
              { error: "Confusing the roles of the four enzymes", reason: "The enzyme names and jobs are not memorized distinctly", fix: "Helicase = unzip | Primase = lead | Polymerase = build | Ligase = glue" },
              { error: "Not knowing why Okazaki fragments form", reason: "Students don't connect fragment formation to antiparallel strand direction", fix: "Polymerase only builds 5'→3'. The lagging strand runs the wrong way, forcing restart-and-build cycles that produce fragments." }
            ],
            summary: "DNA replication occurs in Interphase using 4 enzymes: Helicase (unzips), Primase (leads), DNA Polymerase (builds), and Ligase (glues fragments). One strand (leading) is built smoothly; the other (lagging) is built in Okazaki fragments because polymerase only works 5'→3'. The result is two identical DNA molecules each with one old and one new strand — semi-conservative replication."
          }
        }
      },
      ecology: {
        id: "ecology",
        name: "Unit 2: Ecology",
        lessons: {
          ecology_basics: {
            id: "ecology_basics",
            name: "Ecosystems & Organisms",
            overview: "Ecology is the science of interactions — between living things and their environment. Understanding how organisms fit into ecosystems is the foundation for all environmental science.",
            objectives: [
              "Define ecology, ecosystem, organism, and habitat",
              "Distinguish between biotic and abiotic factors",
              "Explain the concepts of niche, natural selection, and adaptation",
              "Define species, population, and community"
            ],
            keyConcepts: [
              { title: "Ecology", content: "Ecology is the study of how organisms interact with each other and with their environment." },
              { title: "Ecosystem", content: "An ecosystem includes all the living AND non-living things in one area. For example: a pond ecosystem includes fish, plants, water, rocks, and sunlight." },
              { title: "Organism", content: "An organism is the smallest unit in an ecosystem. Every organism needs food, water, and shelter to grow and reproduce." },
              { title: "Habitat", content: "A habitat is the place that provides food, water, and shelter for an organism. If any of these needs is missing, the organism will search for a new habitat." },
              { title: "Biotic vs Abiotic Factors", content: "Biotic factors are living or once-living parts of an ecosystem (plants, animals, dead organisms). Abiotic factors are the non-living parts (water, air, rocks, temperature). Never-living things like water and rocks are always abiotic." },
              { title: "Niche", content: "A niche is the unique role an organism plays in its ecosystem — what it eats, how it finds food, and how it survives. Every organism has its own niche." },
              { title: "Natural Selection & Adaptation", content: "Some organisms have characteristics that make them better suited to their environment — they are naturally selected. The physical traits and behaviors that help them survive are called adaptations." },
              { title: "Species, Population & Community", content: "A species is a group of similar organisms that can breed together. A population is the same species living in the same place at the same time. A community is different populations living together in the same area." }
            ],
            vocabulary: [
              { term: "Ecology", definition: "The study of how organisms interact with each other and with their environment", difficulty: "easy" },
              { term: "Ecosystem", definition: "All living and non-living things in one area", difficulty: "easy" },
              { term: "Organism", definition: "The smallest unit in an ecosystem; needs food, water, and shelter", difficulty: "easy" },
              { term: "Habitat", definition: "The place that provides an organism's needs (food, water, shelter)", difficulty: "easy" },
              { term: "Biotic Factors", definition: "Living or once-living parts of an ecosystem (plants, animals, dead organisms)", difficulty: "medium" },
              { term: "Abiotic Factors", definition: "Non-living parts of an ecosystem (water, air, rocks, temperature)", difficulty: "medium" },
              { term: "Niche", definition: "An organism's unique role and way of living in its ecosystem", difficulty: "medium" },
              { term: "Natural Selection", definition: "The process by which organisms better suited to their environment survive and reproduce more successfully", difficulty: "hard" },
              { term: "Adaptation", definition: "Physical characteristics or behaviors that make an organism better suited to its environment", difficulty: "medium" },
              { term: "Species", definition: "A group of organisms that are similar and can breed together", difficulty: "easy" },
              { term: "Population", definition: "Same species + same place + same time", difficulty: "easy" },
              { term: "Community", definition: "Different populations living together in the same area", difficulty: "medium" }
            ],
            commonMistakes: [
              { error: "Calling water a biotic factor", reason: "Water supports life but is not itself living", fix: "Water is abiotic (never-living). Only organisms and their remains are biotic." },
              { error: "Confusing habitat and niche", reason: "Both relate to where/how an organism lives", fix: "Habitat = WHERE an organism lives. Niche = HOW it lives (its role, food source, behavior)." },
              { error: "Mixing up population and community", reason: "Both involve groups of organisms", fix: "Population = ONE species in one place. Community = MULTIPLE species together." }
            ],
            summary: "Ecology studies organism-environment interactions. Ecosystems include biotic (living) and abiotic (non-living) factors. Each organism has a habitat (where it lives) and a niche (how it lives). Organisms with helpful traits are naturally selected — these traits are called adaptations. Organisms are organized into species → populations → communities."
          },
          ecology_relationships: {
            id: "ecology_relationships",
            name: "Ecosystem Relationships",
            overview: "No organism lives in isolation. From predators and prey to mutualistic partnerships, the relationships between species shape and balance every ecosystem.",
            objectives: [
              "Define and give examples of predation",
              "Distinguish between mutualism, commensalism, and parasitism",
              "Explain the concept of symbiosis",
              "Understand the role of competition in ecosystems"
            ],
            keyConcepts: [
              { title: "Predation", content: "Predation is a relationship where one organism (the predator) hunts and eats another (the prey). This is a +/− relationship: the predator benefits, the prey is harmed. Predation helps balance ecosystems by controlling population sizes." },
              { title: "Competition", content: "Competition occurs when two organisms share the same niche and compete for the same resources. Same niche = competition over food, space, or mates." },
              { title: "Symbiosis", content: "Symbiosis describes any close, long-term relationship between two different species. There are three types: mutualism, commensalism, and parasitism." },
              { title: "Mutualism (+/+)", content: "Both species benefit. Example: bees pollinate flowers while collecting nectar — the bee gets food, the flower gets pollinated." },
              { title: "Commensalism (+/0)", content: "One species benefits, the other is unaffected. Example: a bird building a nest in a tree — the bird benefits, the tree is neither helped nor harmed." },
              { title: "Parasitism (+/−)", content: "One species (the parasite) benefits at the expense of another (the host). Example: ticks feeding on a dog — the tick benefits, the dog is harmed." }
            ],
            vocabulary: [
              { term: "Predation", definition: "A relationship where a predator hunts and eats prey (+/− interaction)", difficulty: "easy" },
              { term: "Predator", definition: "An organism that hunts and eats other organisms", difficulty: "easy" },
              { term: "Prey", definition: "An organism that is hunted and eaten by a predator", difficulty: "easy" },
              { term: "Symbiosis", definition: "A close, long-term relationship between two different species", difficulty: "medium" },
              { term: "Mutualism", definition: "A symbiotic relationship where both species benefit (+/+)", difficulty: "medium" },
              { term: "Commensalism", definition: "A symbiotic relationship where one benefits and the other is unaffected (+/0)", difficulty: "medium" },
              { term: "Parasitism", definition: "A symbiotic relationship where one benefits and the other is harmed (+/−)", difficulty: "medium" },
              { term: "Competition", definition: "A relationship where organisms compete for the same limited resources", difficulty: "medium" }
            ],
            commonMistakes: [
              { error: "Thinking commensalism means one species is harmed", reason: "Students confuse the neutral (0) with negative (−)", fix: "Commensalism = +/0. One wins, one is neutral. Parasitism = +/−. One wins, one loses." },
              { error: "Saying predation and parasitism are the same", reason: "Both involve one organism harming another", fix: "Predators kill and eat prey immediately. Parasites live on/in the host over time without killing it right away." }
            ],
            summary: "Species interact in several ways: predation (+/−), competition (both lose resources), and symbiosis. Symbiosis has three forms: mutualism (+/+, both benefit), commensalism (+/0, one benefits, one neutral), and parasitism (+/−, one benefits, one harmed)."
          }
        }
      }
    }
  }
};

// All questions pool
const ALL_QUESTIONS = [
  // DNA Basics
  { id: "q1", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Structure", difficulty: "easy", question: "What does DNA stand for?", correct: "Deoxyribonucleic Acid", wrong: ["Dioxyribo Nucleic Acid", "Double-helix Nucleic Acid", "Deoxyribose Nuclear Acid"], explanation: "DNA stands for Deoxyribonucleic Acid — named after the deoxyribose sugar in its nucleotides.", type: "mc" },
  { id: "q2", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Location", difficulty: "easy", question: "Where is DNA located in the cell?", correct: "In the nucleus", wrong: ["In the mitochondria", "In the cell membrane", "In the cytoplasm"], explanation: "DNA is stored in the nucleus of the cell, organized into chromosomes.", type: "mc" },
  { id: "q3", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Structure", difficulty: "easy", question: "DNA has a double helix structure.", correct: "True", wrong: ["False"], explanation: "DNA consists of two strands twisted around each other, forming the famous double helix.", type: "tf" },
  { id: "q4", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "Nucleotide", difficulty: "medium", question: "What are the three components of a nucleotide?", correct: "Sugar, phosphate group, and nitrogenous base", wrong: ["Sugar, nitrogen, and phosphate", "Protein, sugar, and base", "Amino acid, sugar, and phosphate"], explanation: "A nucleotide = deoxyribose sugar + phosphate group + nitrogenous base (A, T, C, or G).", type: "mc" },
  { id: "q5", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "Base Pairing", difficulty: "medium", question: "Which base pairs with Adenine in DNA?", correct: "Thymine", wrong: ["Uracil", "Guanine", "Cytosine"], explanation: "In DNA, Adenine (A) pairs with Thymine (T) using 2 hydrogen bonds. Remember: A-T, C-G.", type: "mc" },
  { id: "q6", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "Base Pairing", difficulty: "medium", question: "How many hydrogen bonds connect Cytosine to Guanine?", correct: "3", wrong: ["2", "1", "4"], explanation: "C-G pairs are connected by 3 hydrogen bonds. A-T pairs have only 2.", type: "mc" },
  { id: "q7", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Structure", difficulty: "hard", question: "Adenine and Guanine are double-ringed (purines), while Thymine and Cytosine are single-ringed.", correct: "True", wrong: ["False"], explanation: "Purines (A, G) have double rings. Pyrimidines (T, C, U) have single rings.", type: "tf" },
  { id: "q8", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Function", difficulty: "easy", question: "What is the main function of DNA?", correct: "Store and code genetic information", wrong: ["Transport oxygen in the blood", "Build cell walls", "Digest food"], explanation: "DNA stores and codes the genetic information of organisms — it's the instruction manual of the body.", type: "mc" },
  // DNA vs RNA
  { id: "q9", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "RNA Structure", difficulty: "easy", question: "RNA is single-stranded.", correct: "True", wrong: ["False"], explanation: "Unlike DNA (double-stranded), RNA is single-stranded.", type: "tf" },
  { id: "q10", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "RNA Bases", difficulty: "medium", question: "Which base is found in RNA but NOT in DNA?", correct: "Uracil", wrong: ["Thymine", "Adenine", "Guanine"], explanation: "RNA uses Uracil (U) instead of Thymine (T). Remember: 'Apple Under the tree' for A-U.", type: "mc" },
  { id: "q11", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "RNA Function", difficulty: "medium", question: "Why does DNA need RNA?", correct: "DNA cannot leave the nucleus, so RNA carries its code out to make proteins", wrong: ["DNA is too large to function alone", "RNA provides energy for DNA", "RNA repairs damaged DNA strands"], explanation: "DNA stays in the nucleus. RNA exits the nucleus to carry the genetic code to ribosomes for protein synthesis.", type: "mc" },
  { id: "q12", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "Biomolecules", difficulty: "medium", question: "DNA and RNA belong to which family of biomolecules?", correct: "Nucleic Acids", wrong: ["Carbohydrates", "Proteins", "Fats"], explanation: "DNA and RNA are both nucleic acids — one of four biomolecule families (carbohydrates, proteins, fats, nucleic acids).", type: "mc" },
  // DNA Replication
  { id: "q13", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication Enzymes", difficulty: "medium", question: "Which enzyme unzips the DNA double helix during replication?", correct: "Helicase", wrong: ["Ligase", "DNA Polymerase", "Primase"], explanation: "Helicase breaks the hydrogen bonds between base pairs, separating the two strands.", type: "mc" },
  { id: "q14", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication Enzymes", difficulty: "medium", question: "Which enzyme builds new DNA strands during replication?", correct: "DNA Polymerase", wrong: ["Helicase", "Ligase", "Primase"], explanation: "DNA Polymerase is the builder — it picks up free nucleotides and assembles them into a new strand.", type: "mc" },
  { id: "q15", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication Enzymes", difficulty: "hard", question: "What is the role of Ligase in DNA replication?", correct: "It glues together Okazaki fragments", wrong: ["It unzips the DNA strands", "It marks where DNA polymerase starts", "It removes used nucleotides"], explanation: "Ligase acts like glue, sealing the Okazaki fragments on the lagging strand into one continuous strand.", type: "mc" },
  { id: "q16", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Okazaki Fragments", difficulty: "hard", question: "Why does DNA polymerase produce Okazaki fragments on the lagging strand?", correct: "Because it can only build in the 5' to 3' direction, opposite to the lagging strand", wrong: ["Because the lagging strand is shorter", "Because ligase is not present", "Because helicase moves too slowly"], explanation: "DNA polymerase builds 5'→3'. The lagging strand runs 3'→5', so polymerase must repeatedly restart, creating short fragments (Okazaki fragments).", type: "mc" },
  { id: "q17", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Semi-Conservative", difficulty: "medium", question: "Why is DNA replication called 'semi-conservative'?", correct: "Each new DNA molecule has one old strand and one new strand", wrong: ["Half the DNA is destroyed during replication", "Only half the genome is copied", "Two new strands are made from scratch"], explanation: "Semi-conservative means half is conserved: each daughter molecule retains one original strand.", type: "mc" },
  { id: "q18", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication Timing", difficulty: "easy", question: "When does DNA replication occur?", correct: "During Interphase (S phase)", wrong: ["During Mitosis", "During Meiosis", "After cell division is complete"], explanation: "Replication happens in Interphase — the preparation phase before cell division, specifically in the Synthesis (S) phase.", type: "mc" },
  // Ecology Basics
  { id: "q19", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Definitions", difficulty: "easy", question: "Ecology is the study of how organisms interact with each other and their environment.", correct: "True", wrong: ["False"], explanation: "Ecology examines all the interactions between living things and the world around them.", type: "tf" },
  { id: "q20", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Biotic/Abiotic", difficulty: "medium", question: "Which of the following is an abiotic factor?", correct: "Water", wrong: ["Dead leaves", "Bacteria", "Fungi"], explanation: "Water is a never-living (abiotic) factor. Dead leaves are once-living (biotic). Bacteria and fungi are living (biotic).", type: "mc" },
  { id: "q21", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Niche", difficulty: "medium", question: "What is a niche?", correct: "An organism's unique role and way of surviving in its ecosystem", wrong: ["The physical location where an organism lives", "A type of habitat", "A food chain position"], explanation: "A niche is how an organism lives — what it eats, how it gets food, and how it behaves in its ecosystem.", type: "mc" },
  { id: "q22", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Organization", difficulty: "easy", question: "A population includes organisms of different species living together.", correct: "False", wrong: ["True"], explanation: "A population is the SAME species in the same place at the same time. Different species together = community.", type: "tf" },
  { id: "q23", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Adaptation", difficulty: "medium", question: "A polar bear's white fur is an example of:", correct: "An adaptation", wrong: ["A niche", "A biotic factor", "Competition"], explanation: "White fur helps the polar bear blend into its snowy environment — a physical characteristic that improves survival = adaptation.", type: "mc" },
  // Ecology Relationships
  { id: "q24", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Symbiosis", difficulty: "medium", question: "In mutualism, what happens to both species?", correct: "Both benefit", wrong: ["One benefits, one is harmed", "Both are harmed", "One benefits, the other is unaffected"], explanation: "Mutualism is a +/+ relationship where both species gain an advantage.", type: "mc" },
  { id: "q25", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Symbiosis", difficulty: "medium", question: "A tick feeding on a dog is an example of:", correct: "Parasitism", wrong: ["Mutualism", "Commensalism", "Predation"], explanation: "The tick benefits (+) while the dog is harmed (−). One benefits, one is harmed = parasitism.", type: "mc" },
  { id: "q26", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Predation", difficulty: "easy", question: "Predation is a +/− relationship where the predator benefits and the prey is harmed.", correct: "True", wrong: ["False"], explanation: "Predation: predator (+) kills and eats prey (−). It helps balance ecosystem population sizes.", type: "tf" },
  { id: "q27", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Competition", difficulty: "medium", question: "Competition most likely occurs when two organisms share:", correct: "The same niche", wrong: ["The same predator", "A mutualistic bond", "Different habitats"], explanation: "Same niche = same resources needed. This leads to competition over food, space, or mates.", type: "mc" },
  { id: "q28", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Symbiosis", difficulty: "hard", question: "A bird nesting in a tree without affecting the tree is an example of:", correct: "Commensalism", wrong: ["Mutualism", "Parasitism", "Predation"], explanation: "The bird benefits (+), the tree is unaffected (0). One benefits, one neutral = commensalism.", type: "mc" }
];

const FLASHCARDS = [
  { id: "f1", front: "What does DNA stand for?", back: "Deoxyribonucleic Acid", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Basics", difficulty: "easy" },
  { id: "f2", front: "What is the monomer of DNA?", back: "A nucleotide (sugar + phosphate + nitrogenous base)", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Basics", difficulty: "easy" },
  { id: "f3", front: "Which bases pair in DNA?", back: "A pairs with T (2 H-bonds) | C pairs with G (3 H-bonds)", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "Base Pairs", difficulty: "medium" },
  { id: "f4", front: "What is the structure of DNA?", back: "Double helix — 2 strands twisted around each other like a twisted ladder", subject: "biology", unit: "genetics", lesson: "dna_basics", topic: "DNA Basics", difficulty: "easy" },
  { id: "f5", front: "Which base does RNA have that DNA doesn't?", back: "Uracil (U) — replaces Thymine", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "RNA", difficulty: "medium" },
  { id: "f6", front: "Why does DNA need RNA?", back: "DNA cannot leave the nucleus. RNA carries the code out to build proteins.", subject: "biology", unit: "genetics", lesson: "dna_rna", topic: "RNA Function", difficulty: "medium" },
  { id: "f7", front: "Name the 4 enzymes in DNA replication in order", back: "1. Helicase (unzip) → 2. Primase (lead) → 3. DNA Polymerase (build) → 4. Ligase (glue)", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication Enzymes", difficulty: "hard" },
  { id: "f8", front: "What is semi-conservative replication?", back: "Each new DNA molecule has one OLD strand + one NEW strand", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication", difficulty: "hard" },
  { id: "f9", front: "What are Okazaki fragments?", back: "Short DNA fragments on the lagging strand (because polymerase only builds 5'→3')", subject: "biology", unit: "genetics", lesson: "dna_replication", topic: "Replication", difficulty: "hard" },
  { id: "f10", front: "Define: Ecology", back: "The study of how organisms interact with each other and with their environment", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Ecology Basics", difficulty: "easy" },
  { id: "f11", front: "What is the difference between biotic and abiotic?", back: "Biotic = living or once-living (plants, animals, dead organisms) | Abiotic = non-living (water, air, rocks)", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Biotic/Abiotic", difficulty: "medium" },
  { id: "f12", front: "What is a niche?", back: "An organism's unique role in its ecosystem — what it eats, how it survives", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Ecology Basics", difficulty: "medium" },
  { id: "f13", front: "Mutualism vs Parasitism vs Commensalism", back: "Mutualism = +/+ (both benefit) | Parasitism = +/− (one harms other) | Commensalism = +/0 (one benefits, other unaffected)", subject: "biology", unit: "ecology", lesson: "ecology_relationships", topic: "Symbiosis", difficulty: "medium" },
  { id: "f14", front: "What is natural selection?", back: "The process where organisms better suited to their environment survive and reproduce more", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Natural Selection", difficulty: "hard" },
  { id: "f15", front: "Species → Population → Community", back: "Species = can breed together | Population = same species, same place, same time | Community = different populations together", subject: "biology", unit: "ecology", lesson: "ecology_basics", topic: "Organization", difficulty: "medium" }
];

// ── APP ───────────────────────────────────────────────────────────────────────

const initialStats = {
  questionsAnswered: 0, correct: 0, incorrect: 0,
  lessonsCompleted: [], flashcardsStudied: 0,
  streak: 3, bestStreak: 7, studyTime: 142,
  achievements: ["first_quiz", "first_lesson"],
  masteryByLesson: { dna_basics: 65, dna_rna: 40, dna_replication: 25, ecology_basics: 55, ecology_relationships: 30 },
  mistakes: []
};

export default function StudySphere() {
  const [page, setPage] = useState("dashboard");
  const [stats, setStats] = useState(initialStats);
  const [quizState, setQuizState] = useState(null);
  const [flashcardState, setFlashcardState] = useState(null);
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [lessonTab, setLessonTab] = useState("overview");
  const [assistantHistory, setAssistantHistory] = useState([{ role: "system", text: "Welcome to StudySphere! Type /help to see available commands, or ask me anything about your lessons." }]);
  const [assistantInput, setAssistantInput] = useState("");
  const [shooterState, setShooterState] = useState(null);
  const [darkMode, setDarkMode] = useState(true);
  const chatEndRef = useRef(null);

  // ── PHONE DETECTION ──────────────────────────────────────────────────────────
  const [phoneDetectEnabled, setPhoneDetectEnabled] = useState(false);
  const [phoneDetectStatus, setPhoneDetectStatus] = useState("idle"); // idle | loading | active | error
  const [phoneDetectError, setPhoneDetectError] = useState("");
  const [phoneAlert, setPhoneAlert] = useState(false);
  const [phoneWarnings, setPhoneWarnings] = useState(0);
  const [scoreResetMsg, setScoreResetMsg] = useState(false);
  const videoRef = useRef(null);
  const modelRef = useRef(null);
  const streamRef = useRef(null);
  const detectionLoopRef = useRef(null);
  const phoneAlertRef = useRef(false);

  useEffect(() => { phoneAlertRef.current = phoneAlert; }, [phoneAlert]);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [assistantHistory]);

  const loadScript = (src) => new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
    const script = document.createElement("script");
    script.src = src;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load " + src));
    document.head.appendChild(script);
  });

  const triggerPhoneAlert = () => setPhoneAlert(true);

  const detectPhone = async () => {
    if (!modelRef.current || !videoRef.current) return;
    if (phoneAlertRef.current) return;
    if (videoRef.current.readyState < 2) return;
    try {
      const predictions = await modelRef.current.detect(videoRef.current);
      const found = predictions.find(p => p.class === "cell phone" && p.score > 0.55);
      if (found) triggerPhoneAlert();
    } catch (e) { /* ignore frame errors */ }
  };

  const dismissPhoneAlert = () => {
    const newWarnings = phoneWarnings + 1;
    if (newWarnings >= 3) {
      setStats(s => ({
        ...s,
        questionsAnswered: 0,
        correct: 0,
        incorrect: 0,
        streak: 0,
        mistakes: [],
        masteryByLesson: Object.fromEntries(Object.keys(s.masteryByLesson).map(k => [k, 0]))
      }));
      setPhoneWarnings(0);
      setScoreResetMsg(true);
      setTimeout(() => setScoreResetMsg(false), 3000);
    } else {
      setPhoneWarnings(newWarnings);
    }
    setPhoneAlert(false);
  };

  useEffect(() => {
    if (!phoneDetectEnabled) {
      if (detectionLoopRef.current) { clearInterval(detectionLoopRef.current); detectionLoopRef.current = null; }
      if (streamRef.current) { streamRef.current.getTracks().forEach(t => t.stop()); streamRef.current = null; }
      modelRef.current = null;
      setPhoneDetectStatus("idle");
      setPhoneAlert(false);
      setPhoneWarnings(0);
      return;
    }
    let cancelled = false;
    const setup = async () => {
      setPhoneDetectStatus("loading");
      setPhoneDetectError("");
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error("Camera API not available in this environment (likely blocked by the sandbox).");
        }
        try {
          await loadScript("https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js");
          await loadScript("https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd@2.2.2/dist/coco-ssd.min.js");
        } catch (e) {
          throw new Error("Could not load detection model from CDN (blocked or offline).");
        }
        if (cancelled) return;
        let stream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
        } catch (e) {
          throw new Error("Camera access denied or blocked: " + (e && e.message ? e.message : e.name || "unknown"));
        }
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        const model = await window.cocoSsd.load();
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        modelRef.current = model;
        setPhoneDetectStatus("active");
        detectionLoopRef.current = setInterval(detectPhone, 2500);
      } catch (e) {
        if (!cancelled) {
          setPhoneDetectStatus("error");
          setPhoneDetectError(e && e.message ? e.message : String(e));
        }
      }
    };
    setup();
    return () => {
      cancelled = true;
      if (detectionLoopRef.current) { clearInterval(detectionLoopRef.current); detectionLoopRef.current = null; }
      if (streamRef.current) { streamRef.current.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    };
  }, [phoneDetectEnabled]);

  const accuracy = stats.questionsAnswered > 0 ? Math.round((stats.correct / stats.questionsAnswered) * 100) : 0;
  const overallMastery = Math.round(Object.values(stats.masteryByLesson).reduce((a, b) => a + b, 0) / Object.values(stats.masteryByLesson).length);

  const theme = {
    bg: darkMode ? "#0f172a" : "#f8fafc",
    card: darkMode ? "#1e293b" : "#ffffff",
    card2: darkMode ? "#263447" : "#f1f5f9",
    border: darkMode ? "#334155" : "#e2e8f0",
    text: darkMode ? "#f1f5f9" : "#0f172a",
    muted: darkMode ? "#94a3b8" : "#64748b",
    accent: "#10b981",
    accent2: "#3b82f6",
    accent3: "#8b5cf6",
    danger: "#ef4444",
    warn: "#f59e0b"
  };

  const s = (style) => style;

  // ── QUIZ ENGINE ──────────────────────────────────────────────────────────────
  const startQuiz = (lessonId = null, difficulty = "mixed", count = 10) => {
    let pool = [...ALL_QUESTIONS];
    if (lessonId) pool = pool.filter(q => q.lesson === lessonId);
    if (difficulty !== "mixed") pool = pool.filter(q => q.difficulty === difficulty);
    pool = pool.sort(() => Math.random() - 0.5).slice(0, Math.min(count, pool.length));
    pool = pool.map(q => {
      const opts = [q.correct, ...q.wrong].sort(() => Math.random() - 0.5);
      return { ...q, options: opts };
    });
    setQuizState({ questions: pool, index: 0, selected: null, answered: false, score: 0, results: [], finished: false });
    setPage("quiz_active");
  };

  const answerQuestion = (option) => {
    if (quizState.answered) return;
    const q = quizState.questions[quizState.index];
    const correct = option === q.correct;
    const newResults = [...quizState.results, { question: q, selected: option, correct }];
    const newStats = {
      ...stats,
      questionsAnswered: stats.questionsAnswered + 1,
      correct: correct ? stats.correct + 1 : stats.correct,
      incorrect: correct ? stats.incorrect : stats.incorrect + 1,
      mistakes: correct ? stats.mistakes : [...stats.mistakes, { question: q.question, studentAnswer: option, correctAnswer: q.correct, explanation: q.explanation, lesson: q.lesson, topic: q.topic, difficulty: q.difficulty, date: new Date().toLocaleDateString() }]
    };
    setStats(newStats);
    setQuizState({ ...quizState, selected: option, answered: true, score: correct ? quizState.score + 1 : quizState.score, results: newResults });
  };

  const nextQuestion = () => {
    const next = quizState.index + 1;
    if (next >= quizState.questions.length) {
      setQuizState({ ...quizState, finished: true });
    } else {
      setQuizState({ ...quizState, index: next, selected: null, answered: false });
    }
  };

  // ── FLASHCARD ENGINE ─────────────────────────────────────────────────────────
  const startFlashcards = (lessonId = null) => {
    let cards = [...FLASHCARDS];
    if (lessonId) cards = cards.filter(c => c.lesson === lessonId);
    cards = cards.sort(() => Math.random() - 0.5);
    setFlashcardState({ cards, index: 0, flipped: false, studied: 0, favorites: [] });
    setPage("flashcards_active");
  };

  // ── STUDY ASSISTANT ───────────────────────────────────────────────────────────
  const handleAssistant = (input) => {
    const cmd = input.trim().toLowerCase();
    let response = "";
    if (cmd === "/help") response = "Commands: /wrong /hint /review /summary /terms /progress /flashcards /lesson /streak /mastery /weak /recommend /search [term] /formula /easy /medium /hard /favorite /exam";
    else if (cmd === "/progress") response = `📊 Your stats: ${stats.questionsAnswered} questions answered | ${accuracy}% accuracy | ${stats.streak} day streak | Overall mastery: ${overallMastery}%`;
    else if (cmd === "/streak") response = `🔥 Current streak: ${stats.streak} days | Best streak: ${stats.bestStreak} days. Keep it up!`;
    else if (cmd === "/mastery") response = `🎯 Mastery levels:\n• DNA Basics: ${stats.masteryByLesson.dna_basics}% (Advanced)\n• DNA vs RNA: ${stats.masteryByLesson.dna_rna}% (Learning)\n• DNA Replication: ${stats.masteryByLesson.dna_replication}% (Beginner)\n• Ecology Basics: ${stats.masteryByLesson.ecology_basics}% (Skilled)\n• Ecology Relationships: ${stats.masteryByLesson.ecology_relationships}% (Learning)`;
    else if (cmd === "/weak") response = `⚠️ Weakest topics: DNA Replication (${stats.masteryByLesson.dna_replication}%) — focus on enzyme roles and Okazaki fragments. DNA vs RNA (${stats.masteryByLesson.dna_rna}%) — review Uracil vs Thymine.`;
    else if (cmd === "/terms") response = "📚 Key terms: Nucleotide, Double Helix, Helicase, Primase, DNA Polymerase, Ligase, Okazaki Fragments, Semi-conservative, Niche, Biotic, Abiotic, Symbiosis, Mutualism, Commensalism, Parasitism. Type /flashcards to study them!";
    else if (cmd === "/summary") response = "📝 DNA = double helix polymer of nucleotides (A-T, C-G). RNA = single strand using Uracil. Replication uses 4 enzymes: Helicase→Primase→Polymerase→Ligase. Ecology studies organism interactions: biotic vs abiotic, niche, adaptations, symbiosis.";
    else if (cmd === "/recommend") response = `💡 Recommendations:\n1. Study DNA Replication flashcards (lowest mastery at ${stats.masteryByLesson.dna_replication}%)\n2. Take a quiz on Ecosystem Relationships\n3. Review Okazaki fragments — commonly missed topic`;
    else if (cmd === "/formula") response = "🧪 Key formulas/rules:\n• A-T (2 hydrogen bonds) | C-G (3 hydrogen bonds)\n• Purines (double ring): A, G | Pyrimidines (single ring): T, C, U\n• DNA bases: A, T, C, G | RNA bases: A, U, C, G\n• Symbiosis: Mutualism +/+ | Commensalism +/0 | Parasitism +/−";
    else if (cmd === "/review") { response = "Opening Mistake Review..."; setTimeout(() => setPage("mistakes"), 500); }
    else if (cmd === "/flashcards") { response = "Opening Flashcards..."; setTimeout(() => startFlashcards(), 500); }
    else if (cmd.startsWith("/search ")) {
      const term = cmd.replace("/search ", "");
      const found = [...FLASHCARDS.filter(f => f.front.toLowerCase().includes(term) || f.back.toLowerCase().includes(term)), ...ALL_QUESTIONS.filter(q => q.question.toLowerCase().includes(term))];
      response = found.length > 0 ? `🔍 Found ${found.length} result(s) for "${term}". Tip: check flashcards and quizzes for this topic.` : `🔍 No results for "${term}". Try /terms for vocabulary or /formula for rules.`;
    }
    else if (cmd === "/wrong") {
      const lastMistake = stats.mistakes[stats.mistakes.length - 1];
      response = lastMistake ? `❌ Last mistake:\nQ: ${lastMistake.question}\nYou said: ${lastMistake.studentAnswer}\nCorrect: ${lastMistake.correctAnswer}\n💡 ${lastMistake.explanation}` : "No mistakes recorded yet. Take a quiz to get started!";
    }
    else response = `I searched our lesson database for "${input}". Try /help for commands, or ask about DNA, RNA, replication, ecology, or symbiosis!`;

    setAssistantHistory(h => [...h, { role: "user", text: input }, { role: "system", text: response }]);
    setAssistantInput("");
  };

  // ── SHOOTER ───────────────────────────────────────────────────────────────────
  const startShooter = () => {
    const pool = ALL_QUESTIONS.sort(() => Math.random() - 0.5);
    const q = pool[0];
    setShooterState({ questions: pool, index: 0, score: 0, combo: 0, bestCombo: 0, lives: 3, playerX: 50, targetX: 20 + Math.random() * 60, question: q, options: [q.correct, ...q.wrong].sort(() => Math.random() - 0.5), hit: null, finished: false });
    setPage("shooter");
  };

  const shootTarget = (option) => {
    if (!shooterState || shooterState.finished) return;
    const correct = option === shooterState.question.correct;
    const newCombo = correct ? shooterState.combo + 1 : 0;
    const newScore = correct ? shooterState.score + 10 + newCombo * 2 : shooterState.score;
    const newLives = correct ? shooterState.lives : shooterState.lives - 1;
    const nextIdx = shooterState.index + 1;
    const finished = newLives <= 0 || nextIdx >= shooterState.questions.length;
    const nextQ = !finished ? shooterState.questions[nextIdx] : null;
    setShooterState(s => ({
      ...s, score: newScore, combo: newCombo, bestCombo: Math.max(s.bestCombo, newCombo),
      lives: newLives, hit: correct ? "correct" : "wrong", finished,
      index: nextIdx,
      question: nextQ || s.question,
      options: nextQ ? [nextQ.correct, ...nextQ.wrong].sort(() => Math.random() - 0.5) : s.options,
      targetX: 20 + Math.random() * 60
    }));
    setTimeout(() => setShooterState(s => s ? ({ ...s, hit: null }) : null), 800);
  };

  // ── RENDER HELPERS ────────────────────────────────────────────────────────────
  const getMasteryLabel = (pct) => {
    if (pct >= 91) return { label: "Master", color: "#f59e0b" };
    if (pct >= 81) return { label: "Expert", color: "#10b981" };
    if (pct >= 61) return { label: "Advanced", color: "#3b82f6" };
    if (pct >= 41) return { label: "Skilled", color: "#8b5cf6" };
    if (pct >= 21) return { label: "Learning", color: "#f97316" };
    return { label: "Beginner", color: "#ef4444" };
  };

  const Ring = ({ pct, size = 80, stroke = 8, color = "#10b981", label }) => {
    const r = (size - stroke) / 2;
    const circ = 2 * Math.PI * r;
    return (
      <svg width={size} height={size} style={{ display: "block" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={theme.border} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeDasharray={circ} strokeDashoffset={circ * (1 - pct / 100)}
          strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} />
        {label && <text x={size / 2} y={size / 2 + 5} textAnchor="middle" fill={theme.text} fontSize="14" fontWeight="700">{label}</text>}
      </svg>
    );
  };

  const NavBtn = ({ id, icon, label }) => (
    <button onClick={() => setPage(id)} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 14px", borderRadius: "10px", border: "none", cursor: "pointer", width: "100%", textAlign: "left", background: page === id ? `${theme.accent}22` : "transparent", color: page === id ? theme.accent : theme.muted, fontWeight: page === id ? "700" : "400", fontSize: "14px", transition: "all 0.15s" }}>
      <span style={{ fontSize: "18px" }}>{icon}</span>{label}
    </button>
  );

  // ── PAGES ─────────────────────────────────────────────────────────────────────

  const renderDashboard = () => (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "26px", fontWeight: "800", color: theme.text, margin: 0 }}>Welcome back! 👋</h1>
        <p style={{ color: theme.muted, marginTop: "4px" }}>You're on a <span style={{ color: theme.warn, fontWeight: "700" }}>{stats.streak}-day streak</span>. Keep it going!</p>
      </div>

      {/* Quick Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: "12px", marginBottom: "24px" }}>
        {[
          { label: "Accuracy", value: `${accuracy}%`, icon: "🎯", color: theme.accent },
          { label: "Questions", value: stats.questionsAnswered, icon: "❓", color: theme.accent2 },
          { label: "Correct", value: stats.correct, icon: "✅", color: theme.accent },
          { label: "Streak", value: `${stats.streak}d`, icon: "🔥", color: theme.warn },
          { label: "Mastery", value: `${overallMastery}%`, icon: "⭐", color: theme.accent3 },
          { label: "Study Time", value: `${stats.studyTime}m`, icon: "⏱️", color: theme.accent2 },
        ].map(st => (
          <div key={st.label} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: "16px", display: "flex", flexDirection: "column", gap: "4px" }}>
            <span style={{ fontSize: "22px" }}>{st.icon}</span>
            <span style={{ fontSize: "22px", fontWeight: "800", color: st.color }}>{st.value}</span>
            <span style={{ fontSize: "12px", color: theme.muted }}>{st.label}</span>
          </div>
        ))}
      </div>

      {/* Mastery Overview */}
      <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "20px" }}>
        <h2 style={{ fontSize: "16px", fontWeight: "700", color: theme.text, margin: "0 0 16px" }}>📈 Lesson Mastery</h2>
        {Object.entries(stats.masteryByLesson).map(([lessonId, pct]) => {
          const lesson = Object.values(SUBJECTS.biology.units).flatMap(u => Object.values(u.lessons)).find(l => l.id === lessonId);
          const m = getMasteryLabel(pct);
          return (
            <div key={lessonId} style={{ marginBottom: "12px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                <span style={{ fontSize: "13px", color: theme.text, fontWeight: "500" }}>{lesson?.name || lessonId}</span>
                <span style={{ fontSize: "12px", color: m.color, fontWeight: "700" }}>{m.label} {pct}%</span>
              </div>
              <div style={{ height: "6px", background: theme.border, borderRadius: "4px", overflow: "hidden" }}>
                <div style={{ width: `${pct}%`, height: "100%", background: m.color, borderRadius: "4px", transition: "width 0.5s" }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "20px" }}>
        <h2 style={{ fontSize: "16px", fontWeight: "700", color: theme.text, margin: "0 0 14px" }}>⚡ Quick Start</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
          {[
            { label: "Quick Quiz", sub: "10 random questions", icon: "🧠", action: () => startQuiz(null, "mixed", 10), color: theme.accent },
            { label: "Flashcards", sub: "All topics", icon: "🃏", action: () => startFlashcards(), color: theme.accent2 },
            { label: "Study Lessons", sub: "Pick a lesson", icon: "📖", action: () => setPage("subjects"), color: theme.accent3 },
            { label: "Review Mistakes", sub: `${stats.mistakes.length} saved`, icon: "❌", action: () => setPage("mistakes"), color: theme.warn },
          ].map(a => (
            <button key={a.label} onClick={a.action} style={{ background: `${a.color}18`, border: `1px solid ${a.color}44`, borderRadius: "12px", padding: "14px", cursor: "pointer", textAlign: "left" }}>
              <div style={{ fontSize: "22px", marginBottom: "4px" }}>{a.icon}</div>
              <div style={{ fontSize: "13px", fontWeight: "700", color: theme.text }}>{a.label}</div>
              <div style={{ fontSize: "11px", color: theme.muted }}>{a.sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px" }}>
        <h2 style={{ fontSize: "16px", fontWeight: "700", color: theme.text, margin: "0 0 14px" }}>💡 Recommended Next</h2>
        {[
          { icon: "⚠️", text: "Practice DNA Replication", sub: "Lowest mastery — focus on enzymes", action: () => startQuiz("dna_replication") },
          { icon: "🃏", text: "Flashcard: Symbiosis", sub: "Review mutualism vs parasitism", action: () => startFlashcards("ecology_relationships") },
          { icon: "📖", text: "Lesson: DNA Replication", sub: "Review Okazaki fragments", action: () => { setSelectedLesson("dna_replication"); setPage("lesson"); } },
        ].map((r, i) => (
          <div key={i} onClick={r.action} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "12px", borderRadius: "10px", cursor: "pointer", marginBottom: "6px", background: theme.card2, border: `1px solid ${theme.border}` }}>
            <span style={{ fontSize: "20px" }}>{r.icon}</span>
            <div>
              <div style={{ fontSize: "13px", fontWeight: "600", color: theme.text }}>{r.text}</div>
              <div style={{ fontSize: "11px", color: theme.muted }}>{r.sub}</div>
            </div>
            <span style={{ marginLeft: "auto", color: theme.accent }}>→</span>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSubjects = () => {
    const subj = SUBJECTS.biology;
    return (
      <div>
        <h1 style={{ fontSize: "22px", fontWeight: "800", color: theme.text, margin: "0 0 20px" }}>📚 Biology</h1>
        {Object.values(subj.units).map(unit => (
          <div key={unit.id} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "18px", marginBottom: "16px" }}>
            <h2 style={{ fontSize: "16px", fontWeight: "700", color: theme.accent, margin: "0 0 14px" }}>{unit.name}</h2>
            {Object.values(unit.lessons).map(lesson => {
              const m = getMasteryLabel(stats.masteryByLesson[lesson.id] || 0);
              return (
                <div key={lesson.id} style={{ background: theme.card2, border: `1px solid ${theme.border}`, borderRadius: "12px", padding: "14px", marginBottom: "8px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: "14px", fontWeight: "600", color: theme.text }}>{lesson.name}</div>
                      <div style={{ fontSize: "11px", color: m.color, fontWeight: "600", marginTop: "2px" }}>{m.label} — {stats.masteryByLesson[lesson.id] || 0}%</div>
                    </div>
                    <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", justifyContent: "flex-end" }}>
                      <button onClick={() => { setSelectedLesson(lesson.id); setLessonTab("overview"); setPage("lesson"); }} style={{ background: `${theme.accent}22`, color: theme.accent, border: "none", padding: "6px 12px", borderRadius: "8px", fontSize: "12px", cursor: "pointer", fontWeight: "600" }}>📖 Study</button>
                      <button onClick={() => startQuiz(lesson.id)} style={{ background: `${theme.accent2}22`, color: theme.accent2, border: "none", padding: "6px 12px", borderRadius: "8px", fontSize: "12px", cursor: "pointer", fontWeight: "600" }}>🧠 Quiz</button>
                      <button onClick={() => startFlashcards(lesson.id)} style={{ background: `${theme.accent3}22`, color: theme.accent3, border: "none", padding: "6px 12px", borderRadius: "8px", fontSize: "12px", cursor: "pointer", fontWeight: "600" }}>🃏 Cards</button>
                    </div>
                  </div>
                </div>
              );
            })}
            <button onClick={() => startQuiz(null, "mixed", 15)} style={{ marginTop: "8px", background: `${theme.warn}22`, color: theme.warn, border: "none", padding: "8px 16px", borderRadius: "10px", fontSize: "12px", cursor: "pointer", fontWeight: "600" }}>📋 Unit Quiz</button>
          </div>
        ))}
      </div>
    );
  };

  const renderLesson = () => {
    const lesson = Object.values(SUBJECTS.biology.units).flatMap(u => Object.values(u.lessons)).find(l => l.id === selectedLesson);
    if (!lesson) return <div style={{ color: theme.text }}>Lesson not found</div>;
    const tabs = ["overview", "concepts", "vocabulary", "mistakes", "summary", "quiz"];
    const tabLabels = { overview: "Overview", concepts: "Key Concepts", vocabulary: "Vocabulary", mistakes: "Common Mistakes", summary: "Summary", quiz: "Knowledge Check" };
    return (
      <div>
        <button onClick={() => setPage("subjects")} style={{ background: "none", border: "none", color: theme.accent, cursor: "pointer", marginBottom: "12px", fontSize: "14px" }}>← Back</button>
        <h1 style={{ fontSize: "20px", fontWeight: "800", color: theme.text, margin: "0 0 4px" }}>{lesson.name}</h1>
        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", margin: "12px 0 20px" }}>
          {tabs.map(t => (
            <button key={t} onClick={() => setLessonTab(t)} style={{ padding: "6px 14px", borderRadius: "20px", border: "none", cursor: "pointer", fontSize: "12px", fontWeight: "600", background: lessonTab === t ? theme.accent : theme.card2, color: lessonTab === t ? "#fff" : theme.muted }}>
              {tabLabels[t]}
            </button>
          ))}
        </div>

        {lessonTab === "overview" && (
          <div>
            <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "16px" }}>
              <h3 style={{ color: theme.accent, fontSize: "14px", margin: "0 0 10px" }}>📋 Overview</h3>
              <p style={{ color: theme.text, fontSize: "14px", lineHeight: "1.7", margin: 0 }}>{lesson.overview}</p>
            </div>
            <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px" }}>
              <h3 style={{ color: theme.accent2, fontSize: "14px", margin: "0 0 12px" }}>🎯 Learning Objectives</h3>
              {lesson.objectives.map((obj, i) => (
                <div key={i} style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
                  <span style={{ color: theme.accent, fontWeight: "700", fontSize: "13px", minWidth: "20px" }}>{i + 1}.</span>
                  <span style={{ color: theme.text, fontSize: "13px", lineHeight: "1.6" }}>{obj}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {lessonTab === "concepts" && (
          <div>
            {lesson.keyConcepts.map((c, i) => (
              <div key={i} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: "18px", marginBottom: "12px" }}>
                <h3 style={{ color: theme.accent, fontSize: "14px", fontWeight: "700", margin: "0 0 8px" }}>💡 {c.title}</h3>
                <p style={{ color: theme.text, fontSize: "13px", lineHeight: "1.7", margin: 0 }}>{c.content}</p>
              </div>
            ))}
          </div>
        )}

        {lessonTab === "vocabulary" && (
          <div>
            {lesson.vocabulary.map((v, i) => {
              const diffColor = v.difficulty === "easy" ? theme.accent : v.difficulty === "medium" ? theme.warn : theme.danger;
              return (
                <div key={i} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "12px", padding: "14px", marginBottom: "8px", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "12px" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "14px", fontWeight: "700", color: theme.accent, marginBottom: "4px" }}>{v.term}</div>
                    <div style={{ fontSize: "13px", color: theme.text, lineHeight: "1.5" }}>{v.definition}</div>
                  </div>
                  <span style={{ background: `${diffColor}22`, color: diffColor, padding: "2px 8px", borderRadius: "6px", fontSize: "11px", fontWeight: "600", whiteSpace: "nowrap" }}>{v.difficulty}</span>
                </div>
              );
            })}
          </div>
        )}

        {lessonTab === "mistakes" && (
          <div>
            <div style={{ background: `${theme.danger}11`, border: `1px solid ${theme.danger}33`, borderRadius: "12px", padding: "14px", marginBottom: "14px" }}>
              <p style={{ color: theme.muted, fontSize: "13px", margin: 0 }}>⚠️ These are the most common mistakes students make on this topic. Read them carefully before your quiz!</p>
            </div>
            {lesson.commonMistakes.map((m, i) => (
              <div key={i} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: "16px", marginBottom: "10px" }}>
                <div style={{ color: theme.danger, fontWeight: "700", fontSize: "13px", marginBottom: "6px" }}>❌ {m.error}</div>
                <div style={{ color: theme.muted, fontSize: "13px", marginBottom: "6px" }}>Why it happens: {m.reason}</div>
                <div style={{ color: theme.accent, fontWeight: "600", fontSize: "13px" }}>✅ Fix: {m.fix}</div>
              </div>
            ))}
          </div>
        )}

        {lessonTab === "summary" && (
          <div style={{ background: theme.card, border: `1px solid ${theme.accent}44`, borderRadius: "16px", padding: "20px" }}>
            <h3 style={{ color: theme.accent, fontSize: "15px", fontWeight: "700", margin: "0 0 12px" }}>📝 Summary</h3>
            <p style={{ color: theme.text, fontSize: "14px", lineHeight: "1.8", margin: "0 0 20px" }}>{lesson.summary}</p>
            <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
              <button onClick={() => startQuiz(lesson.id)} style={{ background: theme.accent, color: "#fff", border: "none", padding: "10px 20px", borderRadius: "10px", cursor: "pointer", fontWeight: "700", fontSize: "14px" }}>Take Quiz →</button>
              <button onClick={() => startFlashcards(lesson.id)} style={{ background: theme.card2, color: theme.text, border: `1px solid ${theme.border}`, padding: "10px 20px", borderRadius: "10px", cursor: "pointer", fontWeight: "600", fontSize: "14px" }}>Study Flashcards</button>
            </div>
          </div>
        )}

        {lessonTab === "quiz" && (
          <div style={{ textAlign: "center", padding: "20px" }}>
            <div style={{ fontSize: "48px", marginBottom: "16px" }}>🧠</div>
            <h3 style={{ color: theme.text, fontSize: "18px", marginBottom: "8px" }}>Ready for a Knowledge Check?</h3>
            <p style={{ color: theme.muted, marginBottom: "20px" }}>Test what you've learned in this lesson</p>
            {[{ label: "Easy Quiz (5 questions)", diff: "easy", count: 5 }, { label: "Standard Quiz (10 questions)", diff: "mixed", count: 10 }, { label: "Hard Challenge (8 questions)", diff: "hard", count: 8 }].map(opt => (
              <button key={opt.label} onClick={() => startQuiz(lesson.id, opt.diff, opt.count)} style={{ display: "block", width: "100%", background: theme.card, border: `1px solid ${theme.border}`, color: theme.text, padding: "14px", borderRadius: "12px", cursor: "pointer", marginBottom: "10px", fontSize: "14px", fontWeight: "600" }}>{opt.label}</button>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderQuizActive = () => {
    if (!quizState) return null;
    if (quizState.finished) {
      const pct = Math.round((quizState.score / quizState.questions.length) * 100);
      return (
        <div style={{ textAlign: "center", padding: "20px" }}>
          <div style={{ fontSize: "60px", marginBottom: "16px" }}>{pct >= 70 ? "🎉" : pct >= 50 ? "💪" : "📖"}</div>
          <h2 style={{ color: theme.text, fontSize: "22px", marginBottom: "8px" }}>Quiz Complete!</h2>
          <div style={{ fontSize: "48px", fontWeight: "900", color: pct >= 70 ? theme.accent : theme.warn, marginBottom: "4px" }}>{pct}%</div>
          <p style={{ color: theme.muted, marginBottom: "24px" }}>{quizState.score}/{quizState.questions.length} correct</p>
          <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "20px", textAlign: "left" }}>
            {quizState.results.map((r, i) => (
              <div key={i} style={{ display: "flex", gap: "10px", marginBottom: "10px", alignItems: "flex-start" }}>
                <span style={{ fontSize: "16px" }}>{r.correct ? "✅" : "❌"}</span>
                <div>
                  <div style={{ fontSize: "13px", color: theme.text, fontWeight: "600" }}>{r.question.question}</div>
                  {!r.correct && <div style={{ fontSize: "12px", color: theme.danger }}>Your answer: {r.selected}</div>}
                  {!r.correct && <div style={{ fontSize: "12px", color: theme.accent }}>Correct: {r.question.correct}</div>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
            <button onClick={() => startQuiz(null, "mixed", 10)} style={{ background: theme.accent, color: "#fff", border: "none", padding: "12px 24px", borderRadius: "12px", cursor: "pointer", fontWeight: "700" }}>New Quiz</button>
            <button onClick={() => setPage("mistakes")} style={{ background: theme.card2, color: theme.text, border: `1px solid ${theme.border}`, padding: "12px 24px", borderRadius: "12px", cursor: "pointer", fontWeight: "600" }}>Review Mistakes</button>
            <button onClick={() => setPage("dashboard")} style={{ background: theme.card2, color: theme.text, border: `1px solid ${theme.border}`, padding: "12px 24px", borderRadius: "12px", cursor: "pointer", fontWeight: "600" }}>Dashboard</button>
          </div>
        </div>
      );
    }

    const q = quizState.questions[quizState.index];
    const progress = ((quizState.index + 1) / quizState.questions.length) * 100;
    return (
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
          <span style={{ color: theme.muted, fontSize: "13px" }}>{quizState.index + 1} / {quizState.questions.length}</span>
          <span style={{ color: theme.accent, fontWeight: "700", fontSize: "14px" }}>Score: {quizState.score}</span>
        </div>
        <div style={{ height: "6px", background: theme.border, borderRadius: "4px", marginBottom: "20px", overflow: "hidden" }}>
          <div style={{ width: `${progress}%`, height: "100%", background: theme.accent, transition: "width 0.3s" }} />
        </div>
        <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "16px" }}>
          <div style={{ fontSize: "11px", color: theme.muted, marginBottom: "8px" }}>{q.topic} • {q.difficulty}</div>
          <p style={{ color: theme.text, fontSize: "16px", fontWeight: "600", lineHeight: "1.5", margin: 0 }}>{q.question}</p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "16px" }}>
          {q.options.map((opt, i) => {
            let bg = theme.card2, border = theme.border, color = theme.text;
            if (quizState.answered) {
              if (opt === q.correct) { bg = `${theme.accent}22`; border = theme.accent; color = theme.accent; }
              else if (opt === quizState.selected && opt !== q.correct) { bg = `${theme.danger}22`; border = theme.danger; color = theme.danger; }
            } else if (quizState.selected === opt) { bg = `${theme.accent2}22`; border = theme.accent2; }
            return (
              <button key={i} onClick={() => answerQuestion(opt)} style={{ background: bg, border: `2px solid ${border}`, borderRadius: "12px", padding: "14px 16px", color, cursor: quizState.answered ? "default" : "pointer", textAlign: "left", fontSize: "14px", fontWeight: "500", transition: "all 0.2s" }}>
                {opt}
              </button>
            );
          })}
        </div>
        {quizState.answered && (
          <div>
            <div style={{ background: quizState.selected === q.correct ? `${theme.accent}18` : `${theme.danger}18`, border: `1px solid ${quizState.selected === q.correct ? theme.accent : theme.danger}44`, borderRadius: "12px", padding: "14px", marginBottom: "14px" }}>
              <div style={{ fontWeight: "700", color: quizState.selected === q.correct ? theme.accent : theme.danger, marginBottom: "6px" }}>{quizState.selected === q.correct ? "✅ Correct!" : "❌ Incorrect"}</div>
              <p style={{ color: theme.text, fontSize: "13px", lineHeight: "1.6", margin: 0 }}>{q.explanation}</p>
            </div>
            <button onClick={nextQuestion} style={{ width: "100%", background: theme.accent, color: "#fff", border: "none", padding: "14px", borderRadius: "12px", cursor: "pointer", fontWeight: "700", fontSize: "15px" }}>
              {quizState.index + 1 >= quizState.questions.length ? "See Results →" : "Next Question →"}
            </button>
          </div>
        )}
      </div>
    );
  };

  const renderFlashcards = () => {
    if (!flashcardState) return null;
    const card = flashcardState.cards[flashcardState.index];
    const progress = ((flashcardState.index + 1) / flashcardState.cards.length) * 100;
    return (
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
          <span style={{ color: theme.muted, fontSize: "13px" }}>Card {flashcardState.index + 1} / {flashcardState.cards.length}</span>
          <span style={{ color: theme.accent, fontSize: "13px", fontWeight: "600" }}>{flashcardState.studied} studied</span>
        </div>
        <div style={{ height: "5px", background: theme.border, borderRadius: "4px", marginBottom: "20px" }}>
          <div style={{ width: `${progress}%`, height: "100%", background: theme.accent2 }} />
        </div>
        <div onClick={() => setFlashcardState({ ...flashcardState, flipped: !flashcardState.flipped })}
          style={{ background: flashcardState.flipped ? `${theme.accent}18` : theme.card, border: `2px solid ${flashcardState.flipped ? theme.accent : theme.border}`, borderRadius: "20px", padding: "40px 24px", minHeight: "180px", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center", cursor: "pointer", transition: "all 0.25s", marginBottom: "20px" }}>
          <div style={{ fontSize: "11px", color: theme.muted, marginBottom: "12px" }}>{flashcardState.flipped ? "ANSWER" : "TAP TO FLIP"}</div>
          <p style={{ color: theme.text, fontSize: "17px", fontWeight: flashcardState.flipped ? "600" : "700", lineHeight: "1.6", margin: 0 }}>
            {flashcardState.flipped ? card.back : card.front}
          </p>
          {!flashcardState.flipped && <div style={{ marginTop: "16px", fontSize: "24px", color: theme.muted }}>↕️</div>}
        </div>
        <div style={{ display: "flex", gap: "10px" }}>
          {["Again", "Good", "Easy"].map((label, i) => {
            const colors = [theme.danger, theme.warn, theme.accent];
            const next = () => {
              const newStudied = flashcardState.studied + 1;
              setStats(s => ({ ...s, flashcardsStudied: s.flashcardsStudied + 1 }));
              if (flashcardState.index + 1 >= flashcardState.cards.length) {
                alert(`🎉 Session complete! You studied ${newStudied} cards.`);
                setPage("dashboard");
              } else {
                setFlashcardState({ ...flashcardState, index: flashcardState.index + 1, flipped: false, studied: newStudied });
              }
            };
            return (
              <button key={label} onClick={next} style={{ flex: 1, background: `${colors[i]}22`, border: `1px solid ${colors[i]}44`, color: colors[i], padding: "12px", borderRadius: "12px", cursor: "pointer", fontWeight: "700", fontSize: "14px" }}>{label}</button>
            );
          })}
        </div>
      </div>
    );
  };

  const renderMistakes = () => (
    <div>
      <h1 style={{ fontSize: "20px", fontWeight: "800", color: theme.text, margin: "0 0 16px" }}>❌ Mistake Review</h1>
      {stats.mistakes.length === 0 ? (
        <div style={{ textAlign: "center", padding: "40px", color: theme.muted }}>
          <div style={{ fontSize: "48px", marginBottom: "12px" }}>🎉</div>
          <p>No mistakes yet! Take a quiz to get started.</p>
          <button onClick={() => startQuiz()} style={{ background: theme.accent, color: "#fff", border: "none", padding: "12px 24px", borderRadius: "12px", cursor: "pointer", fontWeight: "700", marginTop: "12px" }}>Start Quiz</button>
        </div>
      ) : (
        <>
          <div style={{ display: "flex", gap: "10px", marginBottom: "16px" }}>
            <button onClick={() => { const qs = ALL_QUESTIONS.filter(q => stats.mistakes.some(m => m.question === q.question)); startQuiz(); }} style={{ background: theme.danger, color: "#fff", border: "none", padding: "10px 18px", borderRadius: "10px", cursor: "pointer", fontWeight: "700", fontSize: "13px" }}>Retry Mistakes Quiz</button>
          </div>
          {stats.mistakes.map((m, i) => (
            <div key={i} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: "16px", marginBottom: "10px" }}>
              <div style={{ fontSize: "12px", color: theme.muted, marginBottom: "6px" }}>{m.lesson} • {m.topic} • {m.date}</div>
              <div style={{ color: theme.text, fontWeight: "600", fontSize: "13px", marginBottom: "8px" }}>❓ {m.question}</div>
              <div style={{ color: theme.danger, fontSize: "13px", marginBottom: "4px" }}>✗ Your answer: {m.studentAnswer}</div>
              <div style={{ color: theme.accent, fontSize: "13px", marginBottom: "8px" }}>✓ Correct: {m.correctAnswer}</div>
              <div style={{ color: theme.muted, fontSize: "12px", fontStyle: "italic" }}>💡 {m.explanation}</div>
            </div>
          ))}
        </>
      )}
    </div>
  );

  const renderProgress = () => (
    <div>
      <h1 style={{ fontSize: "20px", fontWeight: "800", color: theme.text, margin: "0 0 20px" }}>📊 Progress & Statistics</h1>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "20px" }}>
        {[
          { label: "Questions Answered", value: stats.questionsAnswered, icon: "❓" },
          { label: "Correct Answers", value: stats.correct, icon: "✅" },
          { label: "Incorrect Answers", value: stats.incorrect, icon: "❌" },
          { label: "Accuracy", value: `${accuracy}%`, icon: "🎯" },
          { label: "Flashcards Studied", value: stats.flashcardsStudied, icon: "🃏" },
          { label: "Current Streak", value: `${stats.streak} days`, icon: "🔥" },
          { label: "Best Streak", value: `${stats.bestStreak} days`, icon: "⭐" },
          { label: "Study Time", value: `${stats.studyTime} min`, icon: "⏱️" },
        ].map(st => (
          <div key={st.label} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: "16px" }}>
            <div style={{ fontSize: "22px", marginBottom: "6px" }}>{st.icon}</div>
            <div style={{ fontSize: "20px", fontWeight: "800", color: theme.accent }}>{st.value}</div>
            <div style={{ fontSize: "11px", color: theme.muted, marginTop: "2px" }}>{st.label}</div>
          </div>
        ))}
      </div>
      <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "20px", marginBottom: "16px" }}>
        <h2 style={{ fontSize: "15px", fontWeight: "700", color: theme.text, margin: "0 0 16px" }}>Mastery by Lesson</h2>
        {Object.entries(stats.masteryByLesson).map(([lid, pct]) => {
          const lesson = Object.values(SUBJECTS.biology.units).flatMap(u => Object.values(u.lessons)).find(l => l.id === lid);
          const m = getMasteryLabel(pct);
          return (
            <div key={lid} style={{ display: "flex", alignItems: "center", gap: "14px", marginBottom: "14px" }}>
              <Ring pct={pct} size={50} stroke={5} color={m.color} label={`${pct}`} />
              <div>
                <div style={{ fontSize: "13px", fontWeight: "600", color: theme.text }}>{lesson?.name}</div>
                <div style={{ fontSize: "11px", color: m.color, fontWeight: "600" }}>{m.label}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderAssistant = () => (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 100px)" }}>
      <h1 style={{ fontSize: "18px", fontWeight: "800", color: theme.text, margin: "0 0 14px" }}>🤖 Study Assistant</h1>
      <div style={{ background: `${theme.accent2}18`, border: `1px solid ${theme.accent2}44`, borderRadius: "10px", padding: "10px 14px", marginBottom: "12px" }}>
        <span style={{ fontSize: "12px", color: theme.muted }}>Uses lesson database & rules — no AI. Type <strong style={{ color: theme.accent2 }}>/help</strong> for commands.</span>
      </div>
      <div style={{ flex: 1, overflowY: "auto", marginBottom: "12px", display: "flex", flexDirection: "column", gap: "8px" }}>
        {assistantHistory.map((msg, i) => (
          <div key={i} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{ background: msg.role === "user" ? theme.accent : theme.card, color: msg.role === "user" ? "#fff" : theme.text, border: msg.role === "user" ? "none" : `1px solid ${theme.border}`, borderRadius: "14px", padding: "10px 14px", maxWidth: "85%", fontSize: "13px", lineHeight: "1.6", whiteSpace: "pre-line" }}>
              {msg.text}
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <input value={assistantInput} onChange={e => setAssistantInput(e.target.value)} onKeyDown={e => e.key === "Enter" && assistantInput.trim() && handleAssistant(assistantInput)}
          placeholder="Type a command or question..." style={{ flex: 1, background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "12px", padding: "12px 16px", color: theme.text, fontSize: "14px", outline: "none" }} />
        <button onClick={() => assistantInput.trim() && handleAssistant(assistantInput)} style={{ background: theme.accent, color: "#fff", border: "none", padding: "12px 18px", borderRadius: "12px", cursor: "pointer", fontWeight: "700" }}>→</button>
      </div>
    </div>
  );

  const renderShooter = () => {
    if (!shooterState) return null;
    if (shooterState.finished) {
      return (
        <div style={{ textAlign: "center", padding: "30px" }}>
          <div style={{ fontSize: "60px", marginBottom: "16px" }}>🚀</div>
          <h2 style={{ color: theme.text, fontSize: "22px" }}>Game Over!</h2>
          <div style={{ fontSize: "48px", fontWeight: "900", color: theme.accent, margin: "12px 0" }}>{shooterState.score}</div>
          <p style={{ color: theme.muted }}>Best Combo: x{shooterState.bestCombo}</p>
          <div style={{ display: "flex", gap: "10px", justifyContent: "center", marginTop: "20px" }}>
            <button onClick={startShooter} style={{ background: theme.accent, color: "#fff", border: "none", padding: "12px 24px", borderRadius: "12px", cursor: "pointer", fontWeight: "700" }}>Play Again</button>
            <button onClick={() => setPage("dashboard")} style={{ background: theme.card2, color: theme.text, border: `1px solid ${theme.border}`, padding: "12px 24px", borderRadius: "12px", cursor: "pointer" }}>Dashboard</button>
          </div>
        </div>
      );
    }
    const q = shooterState.question;
    return (
      <div style={{ background: "#0a0f1e", minHeight: "100%", borderRadius: "16px", padding: "20px", position: "relative", overflow: "hidden" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
          <span style={{ color: "#fff", fontWeight: "700" }}>Score: {shooterState.score}</span>
          <span style={{ color: theme.warn }}>Combo: x{shooterState.combo}</span>
          <span style={{ color: theme.danger }}>{"❤️".repeat(shooterState.lives)}</span>
        </div>
        <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: "12px", padding: "14px", marginBottom: "20px", border: "1px solid rgba(255,255,255,0.1)" }}>
          <p style={{ color: "#fff", fontSize: "14px", fontWeight: "600", margin: 0, textAlign: "center" }}>{q.question}</p>
        </div>
        {shooterState.hit && (
          <div style={{ textAlign: "center", fontSize: "32px", marginBottom: "10px" }}>{shooterState.hit === "correct" ? "💥✅" : "💥❌"}</div>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          {shooterState.options.map((opt, i) => (
            <button key={i} onClick={() => shootTarget(opt)}
              style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: "12px", padding: "14px", color: "#fff", cursor: "pointer", fontSize: "13px", fontWeight: "500", transition: "all 0.15s" }}>
              🎯 {opt}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", gap: "6px", justifyContent: "center", marginTop: "20px" }}>
          {[...Array(5)].map((_, i) => <span key={i} style={{ color: i < shooterState.combo ? theme.warn : "rgba(255,255,255,0.2)", fontSize: "16px" }}>⭐</span>)}
        </div>
      </div>
    );
  };

  const renderAchievements = () => {
    const allAchievements = [
      { id: "first_quiz", icon: "🏆", name: "First Quiz", desc: "Complete your first quiz", earned: true },
      { id: "first_lesson", icon: "📖", name: "First Lesson", desc: "Study your first lesson", earned: true },
      { id: "streak_3", icon: "🔥", name: "3-Day Streak", desc: "Study 3 days in a row", earned: stats.streak >= 3 },
      { id: "streak_7", icon: "⚡", name: "7-Day Streak", desc: "Study 7 days in a row", earned: stats.streak >= 7 },
      { id: "correct_10", icon: "✅", name: "On a Roll", desc: "Get 10 correct answers", earned: stats.correct >= 10 },
      { id: "correct_50", icon: "🌟", name: "Knowledge Builder", desc: "Get 50 correct answers", earned: stats.correct >= 50 },
      { id: "flashcard_10", icon: "🃏", name: "Card Collector", desc: "Study 10 flashcards", earned: stats.flashcardsStudied >= 10 },
      { id: "mastery_adv", icon: "🎓", name: "Subject Expert", desc: "Reach Advanced on any lesson", earned: Object.values(stats.masteryByLesson).some(p => p >= 61) },
    ];
    return (
      <div>
        <h1 style={{ fontSize: "20px", fontWeight: "800", color: theme.text, margin: "0 0 8px" }}>🏆 Achievements</h1>
        <p style={{ color: theme.muted, fontSize: "13px", marginBottom: "20px" }}>{allAchievements.filter(a => a.earned).length} / {allAchievements.length} earned</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
          {allAchievements.map(a => (
            <div key={a.id} style={{ background: a.earned ? `${theme.accent}18` : theme.card, border: `1px solid ${a.earned ? theme.accent : theme.border}`, borderRadius: "14px", padding: "16px", opacity: a.earned ? 1 : 0.5 }}>
              <div style={{ fontSize: "28px", marginBottom: "8px" }}>{a.earned ? a.icon : "🔒"}</div>
              <div style={{ fontSize: "13px", fontWeight: "700", color: theme.text }}>{a.name}</div>
              <div style={{ fontSize: "11px", color: theme.muted, marginTop: "4px" }}>{a.desc}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderQuizCreator = () => (
    <div>
      <h1 style={{ fontSize: "20px", fontWeight: "800", color: theme.text, margin: "0 0 20px" }}>🧠 Quiz Creator</h1>
      {Object.values(SUBJECTS.biology.units).map(unit => (
        <div key={unit.id} style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "18px", marginBottom: "16px" }}>
          <h2 style={{ color: theme.accent, fontSize: "15px", margin: "0 0 14px" }}>{unit.name}</h2>
          {Object.values(unit.lessons).map(lesson => (
            <div key={lesson.id} style={{ marginBottom: "12px" }}>
              <div style={{ fontSize: "13px", fontWeight: "600", color: theme.text, marginBottom: "8px" }}>{lesson.name}</div>
              <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                {["easy", "medium", "hard", "mixed"].map(diff => (
                  <button key={diff} onClick={() => startQuiz(lesson.id, diff, 10)} style={{ background: theme.card2, border: `1px solid ${theme.border}`, color: theme.muted, padding: "5px 12px", borderRadius: "8px", cursor: "pointer", fontSize: "12px", fontWeight: "600", textTransform: "capitalize" }}>{diff}</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      ))}
      <div style={{ background: theme.card, border: `1px solid ${theme.border}`, borderRadius: "16px", padding: "18px" }}>
        <h2 style={{ color: theme.warn, fontSize: "15px", margin: "0 0 14px" }}>🎲 Full Subject Quiz</h2>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {[10, 25, 50].map(n => (
            <button key={n} onClick={() => startQuiz(null, "mixed", n)} style={{ background: `${theme.warn}22`, border: `1px solid ${theme.warn}44`, color: theme.warn, padding: "8px 16px", borderRadius: "10px", cursor: "pointer", fontWeight: "700", fontSize: "13px" }}>{n} Questions</button>
          ))}
        </div>
      </div>
    </div>
  );

  // ── LAYOUT ────────────────────────────────────────────────────────────────────
  const navItems = [
    { id: "dashboard", icon: "🏠", label: "Dashboard" },
    { id: "subjects", icon: "📚", label: "Subjects" },
    { id: "quiz_creator", icon: "🧠", label: "Quiz Creator" },
    { id: "flashcards_active", icon: "🃏", label: "Flashcards" },
    { id: "mistakes", icon: "❌", label: "Mistake Review" },
    { id: "progress", icon: "📊", label: "Progress" },
    { id: "assistant", icon: "🤖", label: "Study Assistant" },
    { id: "shooter", icon: "🚀", label: "Edu Shooter" },
    { id: "achievements", icon: "🏆", label: "Achievements" },
  ];

  const renderContent = () => {
    if (page === "dashboard") return renderDashboard();
    if (page === "subjects") return renderSubjects();
    if (page === "lesson") return renderLesson();
    if (page === "quiz_creator") return renderQuizCreator();
    if (page === "quiz_active") return renderQuizActive();
    if (page === "flashcards_active") {
      if (!flashcardState) { startFlashcards(); return <div style={{ color: theme.text }}>Loading...</div>; }
      return renderFlashcards();
    }
    if (page === "mistakes") return renderMistakes();
    if (page === "progress") return renderProgress();
    if (page === "assistant") return renderAssistant();
    if (page === "shooter") {
      if (!shooterState) { startShooter(); return <div style={{ color: theme.text }}>Loading...</div>; }
      return renderShooter();
    }
    if (page === "achievements") return renderAchievements();
    return renderDashboard();
  };

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, display: "flex", fontFamily: "system-ui, -apple-system, sans-serif" }}>
      <style>{`
        @keyframes phoneAlertPulse {
          0%, 100% { background-color: rgba(220, 38, 38, 0.97); }
          50% { background-color: rgba(120, 0, 0, 0.97); }
        }
        @keyframes phoneAlertShake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-6px); }
          40% { transform: translateX(6px); }
          60% { transform: translateX(-4px); }
          80% { transform: translateX(4px); }
        }
      `}</style>

      {/* Hidden camera feed used for phone detection */}
      <video ref={videoRef} muted playsInline style={{ position: "fixed", width: "2px", height: "2px", opacity: 0, pointerEvents: "none", top: 0, left: 0 }} />

      {/* Phone detected — full screen warning */}
      {phoneAlert && (
        <div style={{ position: "fixed", inset: 0, zIndex: 10000, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "24px", animation: "phoneAlertPulse 1s infinite" }}>
          <div style={{ fontSize: "70px", animation: "phoneAlertShake 0.5s infinite" }}>📵</div>
          <h1 style={{ color: "#fff", fontSize: "clamp(28px, 6vw, 48px)", fontWeight: "900", letterSpacing: "2px", margin: "12px 0 8px", textTransform: "uppercase" }}>Stop Slacking Off!</h1>
          <p style={{ color: "#fff", fontSize: "15px", opacity: 0.9, margin: "0 0 4px", maxWidth: "360px" }}>A phone was spotted on camera. Put it away and get back to studying.</p>
          <p style={{ color: "#fff", fontSize: "13px", fontWeight: "700", margin: "0 0 24px" }}>Warning {phoneWarnings + 1} of 3 — 3 strikes resets your score!</p>
          <button onClick={dismissPhoneAlert} style={{ background: "#fff", color: "#b91c1c", border: "none", padding: "14px 28px", borderRadius: "12px", cursor: "pointer", fontWeight: "800", fontSize: "15px" }}>I put it away — Resume</button>
        </div>
      )}

      {/* Score reset toast */}
      {scoreResetMsg && (
        <div style={{ position: "fixed", top: "20px", right: "20px", zIndex: 10001, background: theme.danger, color: "#fff", padding: "14px 22px", borderRadius: "12px", fontWeight: "800", fontSize: "14px", boxShadow: "0 8px 24px rgba(0,0,0,0.35)" }}>
          ⚠️ Reseted score
        </div>
      )}

      {/* Sidebar */}
      <div style={{ width: "220px", minHeight: "100vh", background: theme.card, borderRight: `1px solid ${theme.border}`, padding: "20px 12px", display: "flex", flexDirection: "column", position: "fixed", left: 0, top: 0, bottom: 0, overflowY: "auto" }}>
        <div style={{ marginBottom: "24px", padding: "0 4px" }}>
          <div style={{ fontSize: "20px", fontWeight: "900", color: theme.accent, letterSpacing: "-0.5px" }}>StudySphere</div>
          <div style={{ fontSize: "11px", color: theme.muted, marginTop: "2px" }}>Biology • Grade Level</div>
        </div>
        <nav style={{ flex: 1 }}>
          {navItems.map(item => <NavBtn key={item.id} {...item} />)}
        </nav>
        <div style={{ borderTop: `1px solid ${theme.border}`, paddingTop: "12px", marginTop: "12px" }}>
          <button onClick={() => setDarkMode(!darkMode)} style={{ display: "flex", alignItems: "center", gap: "8px", background: "none", border: "none", color: theme.muted, cursor: "pointer", fontSize: "13px", padding: "8px 14px", width: "100%" }}>
            {darkMode ? "☀️" : "🌙"} {darkMode ? "Light Mode" : "Dark Mode"}
          </button>
          <button onClick={() => setPhoneDetectEnabled(v => !v)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px", background: phoneDetectEnabled ? `${theme.danger}18` : "none", border: phoneDetectEnabled ? `1px solid ${theme.danger}44` : "none", borderRadius: "10px", color: phoneDetectEnabled ? theme.danger : theme.muted, cursor: "pointer", fontSize: "13px", padding: "8px 14px", width: "100%", marginTop: "4px" }}>
            <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>📵 Phone Watch</span>
            <span style={{ fontWeight: "800", fontSize: "11px" }}>
              {phoneDetectEnabled ? (phoneDetectStatus === "loading" ? "Starting…" : phoneDetectStatus === "active" ? "ON" : phoneDetectStatus === "error" ? "ERROR" : "ON") : "OFF"}
            </span>
          </button>
          {phoneDetectEnabled && phoneDetectStatus === "error" && (
            <div style={{ fontSize: "10px", color: theme.danger, padding: "4px 14px 0", lineHeight: "1.4" }}>
              {phoneDetectError || "Camera/model failed to load."}
              {phoneDetectError.toLowerCase().includes("sandbox") && (
                <div style={{ marginTop: "4px", color: theme.muted }}>
                  Claude artifacts run in a sandboxed iframe that usually can't access your camera, even if your browser has granted permission to the page. This feature needs to be run outside the artifact preview (e.g. as a standalone app) to work.
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main */}
      <div style={{ marginLeft: "220px", flex: 1, padding: "24px", maxWidth: "860px" }}>
        {renderContent()}
      </div>
    </div>
  );
}
